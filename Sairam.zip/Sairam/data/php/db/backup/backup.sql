CREATE DATABASE IF NOT EXISTS `sairam` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci; 

USE `sairam`; 

DROP TABLE IF EXISTS `users`; 

CREATE TABLE `users` (
  `Name` varchar(25) NOT NULL,
  `Username` varchar(30) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Acc_type` varchar(10) NOT NULL,
  `Class` int(15) NOT NULL,
  `Mobile` bigint(10) NOT NULL,
  `Board` varchar(10) NOT NULL,
  `Joined` date NOT NULL,
  `monfee` bigint(10) NOT NULL,
  `mon` int(13) NOT NULL,
  `paid` bigint(10) NOT NULL,
  `pending` bigint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `users` (`Name`, `Username`, `Password`, `Acc_type`, `Class`, `Mobile`, `Board`, `Joined`, `monfee`, `mon`, `paid`, `pending`) VALUES ('Neeraj R','violinistneeraj@gmail.com','$2y$10$UZ.Au6vyZPhZFy/6IqYnO.6EEc5mmSKbBzUlw8xCuVBKy7dP/p/7G','admin',15,8746084205,'None','2020-08-08',0,8,0,0),
('Rashmi R','neerajr4205@gmail.com','$2y$10$3cXO0Zq4.zjr4SMf07DMKuzi.ruAQ2RVwhs7WT7uKk98/67MIAEFi','student',12,9886794309,'state','2020-08-08',2000,12,10000,0),
('Hari','ophari@gmail.com','$2y$10$pyr/RKE5ELI.LeLFUnqjqefnZUeM8..YJPOQUKtpobvxKLRPBMK2W','student',7,1234567890,'cbse','2020-08-08',2000,12,0,10000),
('Ashish','ashish@gmail.com','$2y$10$kjgOBHa7coc/9lfczecIeuIAWlpJAsmZurFCLsZdc2EAjXiqOyPWu','student',12,1234567890,'state','2020-08-08',2000,12,1000,9000);
