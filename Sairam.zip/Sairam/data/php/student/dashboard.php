<?php
	session_start();
	if(!($_SESSION['loggedin']===true)){
		header("location: ../login/login.php");
	}
?>
<!doctype html>
<html>
	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<meta http-equiv="X-UA-Compatible" content="ie=edge" />
		<link rel="icon" href="../../img/icon.jpg" />
		<link href="../../css/admin.css" rel="stylesheet" />
		<title>Sai Ram Sanskruthi Vidhyalaya</title>
	</head>
	<body>
		<header>
			<img src="../../img/logo.png" id="logo" width="180px" />
			<a href="../login/logout.php"><b><i id="login">Log Out</i></b></a>
		</header>
		<main>
			<label for="menu" id="menutxt">&#x2630;</label><input id="menu" type="checkbox">
			<nav>
				<a href="dashboard.php"><h4 style="color:#fff;padding:10px;">Dashboard</h4></a>
				<ul>
					<a href="chckresult.php"><li class="navlist">Check Results</li></a>
					<a href="message.php"><li class="navlist">Messege Instructor</li></a>
					<a href="changepwd.php"><li class="navlist">change Password</li></a>
					<a href="updateinfo.php"><li class="navlist">Update Info</li></a>
				</ul>
				<a href="../login/logout.php"><b><i id="moblogin">Log Out</i></b></a>
			</nav>
			<div class="container">
				<center>
					<img src="../../img/avatar.jpg" id="avatar" alt="Avatar"><br/>
					<?php
						echo $_SESSION['name'] . "<br/>";
						echo $_SESSION['usn'] . "<br/>";
						if($_SESSION['class'] > 12){
							echo "Instructor <br/>";
						}
						else{
							echo "Class " . $_SESSION['class'] . "<br/>";
						}
						echo '<span style="text-transform:uppercase;">' . $_SESSION['Board'] . "</span><br/>";
						if($_SESSION['isadmin'] === true){
							echo "Admin <br/>";
						}
						else{
							echo "Student <br/>";
						}
					?>
				</center>
			</div>
		</main>
		<footer>
			<center style="background:#e6e6e6; margin:0;padding:5px;font-size:12px;"><small>COPYRIGHT &copy;<?php echo date("Y",strtotime('today'));?> SAI RAM SANSKRUTHI VIDHYALAYA</small></center>
		</footer>
	</body>
</html>
