<?php
	$result="";
	if(isset($_POST['send'])){
		require 'data/php/PHPMailerAutoload.php';
		$mail = new PHPMailer;
		
		$mail->Host='smtp.gmail.com';
		$mail->Port=587;
		$mail->SMTPAuth=true;
		$mail->SMPTSecure='tls';
		$mail->Username='neerajwebreply@gmail.com';
		$mail->Password='Neeraj@12';
		
		$mail->setFrom($_POST['mail'],$_POST['name']);
		$mail->addAddress($mailto);
		$mail->addReplyto($_POST['mail'],$_POST['name']);
		
		$mail->isHTML(true);
		$mail->Subject=$_POST['subtxt'];
		$mail->Body='<center><div style="width:95%;height:300px;background-color:#272727;color:#ffffff;"></br>Received From '.$_POST['name'].'<div style="width:90%;height:220px;background-color:#ffffff;color:#000000;margin-top:20px;"></br>'.$_POST['message'].'</div> Reply to  '.$_POST['mail'].'</div></br>From Website...</center>';
		
		if(!$mail->send()){
			$result = "Somthing Went Wrong, Please Try Later";
		}
		else{
			$result = "Thank you ".$_POST['name'].", for contacting us. We will get Back to you Soon!";
		}
	}
?>
