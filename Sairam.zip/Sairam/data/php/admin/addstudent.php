<?php
	session_start();
	if($_SESSION['loggedin']===true){
		if(!($_SESSION['isadmin'] === true)){
			header("location: ../student/dashboard.php");
		}
	}
	else{
		header("location: ../login/login.php");
	}
	$tdy = date("Y-m-d",strtotime('today'));
	$tdymon = date("m",strtotime('today'));
	if(isset($_POST['add'])){
		$name = $_POST['name'];
		$usn = $_POST['mail'];
		$pwd = 'Change@1nce';
		$class = $_POST['class'];
		$mob = $_POST['mob'];
		$board = $_POST['board'];
		$fee = $_POST['fee'];
		$msg = "";
		require_once "../db/config.php";
		$cond = "SELECT * FROM `users` WHERE `Username` = '$usn'";
		$chck = mysqli_query($link, $cond);
		if($chck){
			if(mysqli_num_rows($chck)>0){
				$msg = "Account Already Exists with this Mail ID!";
			}
			else{
				$pwdhash = password_hash($pwd, PASSWORD_DEFAULT);
				$query = "INSERT INTO `users`(`Name`, `Username`, `Password`, `Acc_type`, `Class`, `Mobile`, `Board`, `Joined`, `monfee`, `mon`, `paid`, `pending`) VALUES ('$name','$usn','$pwdhash','student','$class',$mob,'$board','$tdy',$fee,'$tdymon',0,$fee)";
					$result = mysqli_query($link, $query);
					if($result){
						$msg = "Account Created Successfully";
					}
					else{
						$msg = "Accuont not Created";
					}
			}
		}
		else{
			$msg = "False";
		}
		mysqli_close($link);
	}
?>
<!doctype html>
<html>
	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<meta http-equiv="X-UA-Compatible" content="ie=edge" />
		<link rel="icon" href="../../img/icon.jpg" />
		<link href="../../css/admin.css" rel="stylesheet" />
		<title>Sai Ram Sanskruthi Vidhyalaya</title>
	</head>
	<body>
		<header>
			<img src="../../img/logo.png" id="logo" width="180px" />
			<a href="../login/logout.php"><b><i id="login">Log Out</i></b></a>
		</header>
		<main>
			<label for="menu" id="menutxt">&#x2630;</label><input id="menu" type="checkbox">
			<nav>
				<a href="dashboard.php"><h4 style="color:#fff;padding:10px;">Dashboard</h4></a>
				<ul>
					<a href="addstudent.php"><li class="navlist" id="active">Add Student</li></a>
					<a href="updatefee.php"><li class="navlist">Update Fee</li></a>
					<a href="addadmin.php"><li class="navlist">Add Admin</li></a>
					<a href="backup.php"><li class="navlist">Take Backup</li></a>
					<a href="feepending.php"><li class="navlist">Fee Pending</li></a>
					<a href="changepwd.php"><li class="navlist">change Password</li></a>
					<a href="updateinfo.php"><li class="navlist">Update Info</li></a>
					<a href="resetpwd.php"><li class="navlist">Reset Password</li></a>
				</ul>
				<a href="../login/logout.php"><b><i id="moblogin">Log Out</i></b></a>
			</nav>
			<div class="container">
				<center>
					<h4 style="padding:10px;">Add Student</h4>
					<form action="?addstudent" method="POST">
						<table align="center">
							<tr align="center">
								<td><input type="text" name="name" placeholder="Enter Name" required class="txtbox" /></td>
							</tr>
							<tr align="center">
								<td><input type="text" name="mail" placeholder="Enter Mail" required class="txtbox" /></td>
							</tr>
							<tr align="center">
								<td><input type="text" name="mob" placeholder="Enter Mobile Number" required class="txtbox" /></td>
							</tr>
							<tr align="center">
								<td><input type="number" min="1" max="12" name="class" placeholder="Enter Class" required class="txtbox" /></td>
							</tr>
							<tr align="center">
								<td>
									<select name="board" class="txtbox" required>
										<option value="cbse">CBSE</option>
										<option value="icse">ICSE</option>
										<option value="state">STATE</option>
									</select>
								</td>
							</tr>
							<tr align="center">
								<td><input type="text" name="fee" placeholder="Enter Fee Per Month" required class="txtbox" /></td>
							</tr>
							<tr align="center">
								<td><input type="Submit" name="add" value="Add Student" required class="btn" /></td>
							</tr>
							<tr>
								<td><span style="margin:10px;color:red;"><?php echo $msg;?></span></td>
							</tr>
						</table>
					</form>
				</center>
			</div>
		</main>
		<footer>
			<center style="background:#e6e6e6; margin:0;padding:5px;font-size:12px;"><small>COPYRIGHT &copy;<?php echo date("Y",strtotime('today'));?> SAI RAM SANSKRUTHI VIDHYALAYA</small></center>
		</footer>
	</body>
</html>
