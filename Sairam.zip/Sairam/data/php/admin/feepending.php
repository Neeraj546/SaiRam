<?php
	session_start();
	if($_SESSION['loggedin']===true){
		if(!($_SESSION['isadmin'] === true)){
			header("location: ../student/dashboard.php");
		}
	}
	else{
		header("location: ../login/login.php");
	}
	if(isset($_POST['get'])){
		$board = $_POST['board'];
		$class = $_POST['class'];
	}
?>
<!doctype html>
<html>
	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<meta http-equiv="X-UA-Compatible" content="ie=edge" />
		<link rel="icon" href="../../img/icon.jpg" />
		<link href="../../css/admin.css" rel="stylesheet" />
		<title>Sai Ram Sanskruthi Vidhyalaya</title>
		<style>
			td,th{
				text-align:center;
				padding: 5px;
			}
		</style>
	</head>
	<body>
		<header>
			<img src="../../img/logo.png" id="logo" width="180px" />
			<a href="../login/logout.php"><b><i id="login">Log Out</i></b></a>
		</header>
		<main>
			<label for="menu" id="menutxt">&#x2630;</label><input id="menu" type="checkbox">
			<nav>
				<a href="dashboard.php"><h4 style="color:#fff;padding:10px;">Dashboard</h4></a>
				<ul>
					<a href="addstudent.php"><li class="navlist">Add Student</li></a>
					<a href="updatefee.php"><li class="navlist">Update Fee</li></a>
					<a href="addadmin.php"><li class="navlist">Add Admin</li></a>
					<a href="backup.php"><li class="navlist">Take Backup</li></a>
					<a href="feepending.php"><li class="navlist" id="active">Fee Pending</li></a>
					<a href="changepwd.php"><li class="navlist">change Password</li></a>
					<a href="updateinfo.php"><li class="navlist">Update Info</li></a>
					<a href="resetpwd.php"><li class="navlist">Reset Password</li></a>
				</ul>
				<a href="../login/logout.php"><b><i id="moblogin">Log Out</i></b></a>
			</nav>
			<div class="container">
				<center>
					<form action="?get=pending" method="POST">
						<table align="center">
							<tr align="center">
								<td style="padding:5px;">
									<select name="board" required class="txtbox">
										<option value="cbse" <?php if("cbse" === $board){echo "Selected";} ?>>CBSE</option>
										<option value="icse" <?php if("icse" === $board){echo "Selected";} ?>>ICSE</option>
										<option value="state" <?php if("state" === $board){echo "Selected";} ?>>STATE</option>
									</select>
								
									<select name="class" required class="txtbox">
										<option value="1" <?php if("1" === $class){echo "Selected";} ?>>1</option>
										<option value="2" <?php if("2" === $class){echo "Selected";} ?>>2</option>
										<option value="3" <?php if("3" === $class){echo "Selected";} ?>>3</option>
										<option value="4" <?php if("4" === $class){echo "Selected";} ?>>4</option>
										<option value="5" <?php if("5" === $class){echo "Selected";} ?>>5</option>
										<option value="6" <?php if("6" === $class){echo "Selected";} ?>>6</option>
										<option value="7" <?php if("7" === $class){echo "Selected";} ?>>7</option>
										<option value="8" <?php if("8" === $class){echo "Selected";} ?>>8</option>
										<option value="9" <?php if("9" === $class){echo "Selected";} ?>>9</option>
										<option value="10" <?php if("10" === $class){echo "Selected";} ?>>10</option>
										<option value="11" <?php if("11" === $class){echo "Selected";} ?>>11</option>
										<option value="12" <?php if("12" === $class){echo "Selected";} ?>>12</option>
									</select>
								</td>
							</tr>
							<tr align="center">
								<td colspan="2"><input name="get" type="submit" value="Gets Results" class="btn" /></td>
							</tr>
						</table>
					</form>
						<?php
							if(isset($_POST['get'])){
								require_once "../db/config.php";
								$cond = "SELECT * FROM `users` WHERE `Board` = '$board' AND  `Class` = '$class'";
								$chck = mysqli_query($link, $cond);
								if($chck){
									echo '<table border="1" style="width: 80%;padding:10px;">';
									echo "<tr><th>Name</th><th>Fee Pending</th></tr>";
									while($data = mysqli_fetch_array($chck)){
										echo "<tr>";
										echo '<td>' . $data['Name'] . "</td>";
										if($data['pending'] > 0){
											echo "<td>" . $data['pending'] . "</td>";
										}
										else{
											echo "<td>Paid</td>";
										}
										echo "</tr>";
									}
									echo '</table>';
								}
								mysqli_close($link);
							}
						?>
				</center>
			</div>
		</main>
		<footer>
			<center style="background:#e6e6e6; margin:0;padding:5px;font-size:12px;"><small>COPYRIGHT &copy;<?php echo date("Y",strtotime('today'));?> SAI RAM SANSKRUTHI VIDHYALAYA</small></center>
		</footer>
	</body>
</html>
