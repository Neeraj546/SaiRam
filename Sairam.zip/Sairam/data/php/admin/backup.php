<?php
	session_start();
	if($_SESSION['loggedin']===true){
		if(!($_SESSION['isadmin'] === true)){
			header("location: ../student/dashboard.php");
		}
	}
	else{
		header("location: ../login/login.php");
	}
	
		$code = "";
		
		require_once "../db/config.php";
		$code .= "CREATE DATABASE IF NOT EXISTS `sairam` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci; \n\n";
		$code .= "USE `sairam`; \n\n";
		$code .= "DROP TABLE IF EXISTS `users`; \n\n";
		$cond = "SHOW CREATE TABLE `users`";
		$chck = mysqli_fetch_row(mysqli_query($link,$cond));
		if($chck){
			$code .= $chck[1] . ";\n\n\n";
			$table = $chck[0];
			$cond = "SELECT * FROM `users`";
			$chck = mysqli_query($link,$cond);
			if($chck){
				$code .= "INSERT INTO `users` (`Name`, `Username`, `Password`, `Acc_type`, `Class`, `Mobile`, `Board`, `Joined`, `monfee`, `mon`, `paid`, `pending`) VALUES ";
				$numrows = mysqli_num_rows($chck);
				$i = 0;
				while($data = mysqli_fetch_array($chck)){
					$i += 1;
					$code .= "('".$data['Name']."','".$data['Username']."','".$data['Password']."','".$data['Acc_type']."',".$data['Class'].",".$data['Mobile'].",'".$data['Board']."','".$data['Joined']."',".$data['monfee'].",".$data['mon'].",".$data['paid'].",".$data['pending'].")";
					if($i <$numrows){
						$code .= ",\n";
					}
					else{
						$code .= ";\n";
					}
				}
				
			}
		}
		if(isset($_POST['backup'])){
			$dbvalue = $_POST['dbvalue'];
			$filebackup = fopen('../db/backup/backup.sql','w+') or die("Unable to open!");
			fwrite($filebackup,$dbvalue);
			fclose($filebackup);
			$msg = "Backup Successful!";
		}
?>
<!doctype html>
<html>
	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<meta http-equiv="X-UA-Compatible" content="ie=edge" />
		<link rel="icon" href="../../img/icon.jpg" />
		<link href="../../css/admin.css" rel="stylesheet" />
		<?php
			if(isset($_POST['backup'])){
				echo "<style>.downbtn{display:block;}</style>";
			}
		?>
		<title>Sai Ram Sanskruthi Vidhyalaya</title>
	</head>
	<body>
		<header>
			<img src="../../img/logo.png" id="logo" width="180px" />
			<a href="../login/logout.php"><b><i id="login">Log Out</i></b></a>
		</header>
		<main>
			<label for="menu" id="menutxt">&#x2630;</label><input id="menu" type="checkbox">
			<nav>
				<a href="dashboard.php"><h4 style="color:#fff;padding:10px;">Dashboard</h4></a>
				<ul>
					<a href="addstudent.php"><li class="navlist">Add Student</li></a>
					<a href="updatefee.php"><li class="navlist">Update Fee</li></a>
					<a href="addadmin.php"><li class="navlist">Add Admin</li></a>
					<a href="backup.php"><li class="navlist" id="active">Take Backup</li></a>
					<a href="feepending.php"><li class="navlist">Fee Pending</li></a>
					<a href="changepwd.php"><li class="navlist">change Password</li></a>
					<a href="updateinfo.php"><li class="navlist">Update Info</li></a>
					<a href="resetpwd.php"><li class="navlist">Reset Password</li></a>
				</ul>
				<a href="../login/logout.php"><b><i id="moblogin">Log Out</i></b></a>
			</nav>
			<div class="container">
				<center>
					<form action="?backup=1" method="POST">
						<textarea readonly name="dbvalue" id="dbvalue"><?php echo $code; ?></textarea>
						<input type="submit" name="backup" class="btn" value="Backup"/><br/>
						<span><?php echo $msg; ?></span><br/>
					</form>
					<a href="../db/backup/backup.sql" download><input type="button" class="downbtn" value="Download"></a>
				</center>
			</div>
		</main>
		<footer>
			<center style="background:#e6e6e6; margin:0;padding:5px;font-size:12px;"><small>COPYRIGHT &copy;<?php echo date("Y",strtotime('today'));?> SAI RAM SANSKRUTHI VIDHYALAYA</small></center>
		</footer>
	</body>
</html>
