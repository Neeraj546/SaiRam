<?php
	session_start();
	if($_SESSION['loggedin']===true){
		if(!($_SESSION['isadmin'] === true)){
			header("location: ../student/dashboard.php");
		}
	}
	else{
		header("location: ../login/login.php");
	}
?>
<!doctype html>
<html>
	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<meta http-equiv="X-UA-Compatible" content="ie=edge" />
		<link rel="icon" href="../../img/icon.jpg" />
		<link href="../../css/admin.css" rel="stylesheet" />
		<title>Sai Ram Sanskruthi Vidhyalaya</title>
	</head>
	<body>
		<header>
			<img src="../../img/logo.png" id="logo" width="180px" />
			<a href="../login/logout.php"><b><i id="login">Log Out</i></b></a>
		</header>
		<main>
			<label for="menu" id="menutxt">&#x2630;</label><input id="menu" type="checkbox">
			<nav>
				<a href="dashboard.php"><h4 style="color:#fff;padding:10px;">Dashboard</h4></a>
				<ul>
					<a href="addstudent.php"><li class="navlist">Add Student</li></a>
					<a href="updatefee.php"><li class="navlist">Update Fee</li></a>
					<a href="addadmin.php"><li class="navlist">Add Admin</li></a>
					<a href="backup.php"><li class="navlist">Take Backup</li></a>
					<a href="feepending.php"><li class="navlist">Fee Pending</li></a>
					<a href="changepwd.php"><li class="navlist">change Password</li></a>
					<a href="updateinfo.php"><li class="navlist">Update Info</li></a>
					<a href="resetpwd.php"><li class="navlist">Reset Password</li></a>
				</ul>
				<a href="../login/logout.php"><b><i id="moblogin">Log Out</i></b></a>
			</nav>
			<div class="container">
				
			</div>
		</main>
		<footer>
			<center style="background:#e6e6e6; margin:0;padding:5px;font-size:12px;"><small>COPYRIGHT &copy;<?php echo date("Y",strtotime('today'));?> SAI RAM SANSKRUTHI VIDHYALAYA</small></center>
		</footer>
	</body>
</html>
