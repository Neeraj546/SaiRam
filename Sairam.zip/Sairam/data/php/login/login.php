<?php
	session_start();
	$error="";
	if($_SESSION['loggedin'] === true){
		if($_SESSION['isadmin'] === true){
			header("location: ../admin/dashboard.php");
		}
		else{
			header("location: ../student/dashboard.php");
		}
	}
	if(isset($_POST['login'])){
		$usn = $_POST['usn'];
		$pwd = $_POST['pwd'];
		require_once "../db/config.php";
		$cond = "SELECT * FROM `users` WHERE `Username` = '$usn'";
		$chck = mysqli_query($link, $cond);
		if($chck){
			if(mysqli_num_rows($chck)>0){
				$data = mysqli_fetch_array($chck);
				$hashed_password = $data['Password'];
				if(password_verify($pwd, $hashed_password)){
					session_start();
					$_SESSION['name'] = $data['Name'];
					$_SESSION['usn'] = $data['Username'];
					$_SESSION['class'] = $data['Class'];
					$_SESSION['mob'] = $data['Mobile'];
					$_SESSION['Board'] = $data['Board'];
					$_SESSION['year'] = $data['Joined'];
					$_SESSION['fee'] = $data['monfee'];
					$_SESSION['paid'] = $data['paid'];
					$_SESSION['pending'] = $data['pending'];
					$_SESSION['loggedin'] = true;
					if($pwd === "Change@1nce"){
						header("location: changepwd.php");
					}
					if($data['Acc_type'] === "admin"){
						$_SESSION['isadmin'] = true;
						if($pwd === "Change@1nce"){
						header("location: changepwd.php");
						}
						else{
							header("location: ../admin/dashboard.php");
						}
					}
					else{
						$_SESSION['isadmin'] = false;
						if($pwd === "Change@1nce"){
							header("location: changepwd.php");
						}
						else{
							header("location: ../student/dashboard.php");
						}
					}
				}
				else{
					$error = "Wrong Password!";
				}
			}
			else{
				$error = "No Account is Linked with this Username!";
			}
		}
		mysqli_close($link);
	}
?>
<!doctype html>
<html>
	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<meta http-equiv="X-UA-Compatible" content="ie=edge" />
		<link rel="icon" href="../../img/icon.jpg" />
		<link href="../../css/index.css" rel="stylesheet" />
		<title>Sai Ram Sanskruthi Vidhyalaya</title>
	</head>
	<body>
		<header>
			<center><img src="../../img/logo.png" id="logo" width="180px" /></center>
		</header>
		<main><div class="container">
			<center>
				<h3 style="padding:10px;margin-top:30px;">Login</h3>
				<form action="?login" method="post">
					<table align="center">
						<tr align="center">
							<td><input type="text" name="usn" class="txt" required placeholder="Mail ID" /></td>
						</tr>
						<tr align="center">
							<td><input type="password" name="pwd" class="txt" required placeholder="Password" /></td>
						</tr>
						<tr align="center">
							<td><input type="Submit" name="login" value="Login" class="btn"/></td>
						</tr>
						<tr align="center">
							<td><span style="margin:10px;color:red;"><?php echo $error;?></span></td>
						</tr>
					</table>
				</form>
				<a href="#" style="color:blue;padding:5px;text-decoration:none;">Forgot Password? Contact Admin to reset Your Password!</a>
			</center></div>
		</main>
		<footer>
			<center style="background:#e6e6e6; margin:0;padding:5px;font-size:12px;"><small>COPYRIGHT &copy;<?php echo date("Y",strtotime('today'));?> SAI RAM SANSKRUTHI VIDHYALAYA</small></center>
		</footer>
	</body>
</html>
