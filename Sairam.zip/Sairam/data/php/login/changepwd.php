<?php
	session_start();
	if(!($_SESSION['loggedin'] === true)){
		header("location: login.php");
	}
	if(isset($_POST['change'])){
		if($_POST['pwd'] === $_POST['cpwd']){
			$pwd = $_POST['pwd'];
			$usn = $_SESSION['usn'];
			require_once "../db/config.php";
			$pwdhash = password_hash($pwd, PASSWORD_DEFAULT);
			$cond = "UPDATE `users` SET `Password` = '$pwdhash' WHERE `Username` = '$usn'";
			$chck = mysqli_query($link, $cond);
			if($chck){
				if($_SESSION['isadmin'] === true){
					header("location: ../admin/dashboard.php");
				}
				else{
					header("location: ../student/dashboard.php");
				}
			}
			else{
				$msg = "Something went Worng!";
			}
		}
		else{
			$msg = "Password Did not match!";
		}
	}
?>
<!doctype html>
<html>
	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<meta http-equiv="X-UA-Compatible" content="ie=edge" />
		<link rel="icon" href="../../img/icon.jpg" />
		<link href="../../css/index.css" rel="stylesheet" />
		<title>Sai Ram Sanskruthi Vidhyalaya</title>
	</head>
	<body>
		<header>
			<center><img src="../../img/logo.png" id="logo" width="180px" /></center>
		</header>
		<main>
			<div class="container">
				<center>
				<h4 style="padding:10px;">Change Password</h4>
				<form action="?change" method="POST">
					<table>
						<tr>
							<td><input type="password" name="pwd" required placeholder="Enter Password" class="txt"/></td>
						</tr>
						<tr>
							<td><input type="password" name="cpwd" required placeholder="Confirm Password" class="txt"/></td>
						</tr>
						<tr>
							<td><input type="Submit" name="change" value="Change Password" class="btn"/></td>
						</tr>
						<tr>
							<td><span style="margin:10px;color:red;"><?php echo $msg;?></span></td>
						</tr>
					</table>
				</form>
				</center>	
			</div>	
		</main>
		<footer>
			<center style="background:#e6e6e6; margin:0;padding:5px;font-size:12px;"><small>COPYRIGHT &copy;<?php echo date("Y",strtotime('today'));?> SAI RAM SANSKRUTHI VIDHYALAYA</small></center>
		</footer>
	</body>
</html>
