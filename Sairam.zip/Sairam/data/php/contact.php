<?php
	session_start();
	$result="";
	if(isset($_POST['send'])){
		require 'mailer/PHPMailerAutoload.php';
		$mail = new PHPMailer;
		//$mail->SMTPDebug = 4;                               // Enable verbose debug output

		$mail->isSMTP(); 
		$mail->Host='smtp.gmail.com';
		$mail->SMTPAuth=true;
		$mail->Username='neerajwebreply@gmail.com';
		$mail->Password='Neeraj@12';
		$mail->SMTPSecure='tls';
		$mail->Port=587;
		
		
		$mail->setFrom($_POST['mail'],$_POST['name']);
		$mail->addAddress('violinistneeraj@gmail.com');
		$mail->addReplyto($_POST['mail'],$_POST['name']);
		
		$mail->isHTML(true);
		$mail->Subject=$_POST['subtxt'];
		$mail->Body='<center><div style="width:95%;height:300px;background-color:#272727;color:#ffffff;"></br>Received From '.$_POST['name'].'<div style="width:90%;height:220px;background-color:#ffffff;color:#000000;margin-top:20px;"></br>'.$_POST['message'].'</div> Reply to  '.$_POST['mail'].'</div></br>From Website...</center>';
		
		if(!$mail->send()){
			$result = "Somthing Went Wrong, Please Try Later <br/> Mailer Error: " . $mail->ErrorInfo;
		}
		else{
			$result = "Thank you ".$_POST['name'].", for contacting us. We will get Back to you Soon!";
		}
	}
?>
<!doctype html>
<html>
	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<meta http-equiv="X-UA-Compatible" content="ie=edge" />
		<link rel="icon" href="../img/icon.jpg" />
		<link href="../css/index.css" rel="stylesheet" />
		<title>Sai Ram Sanskruthi Vidhyalaya</title>
	</head>
	<body>
		<header>
			<a href="../.."><img src="../img/logo.png" id="logo" width="180px" /></a>
			<?php
				if($_SESSION['loggedin']===true){
					echo '<a href="login/logout.php"><b><i id="login">Log Out</i></b></a>';
				}
				else{
					echo '<a href="login/login.php"><b><i id="login">Login</i></b></a>';
				}
			?>
		</header>
		<main><div class="container">
				<center><h3 style="margin-top:10px;">Leave a Message</h3>
			<form action="?sent=1" method="POST">
				<table class="content">
					<tr align="center">
						<td><input type="text" name="name" placeholder="Enter Your Name" required class="txt"/></td>
					</tr>
					<tr align="center">
						<td><input type="text" name="mail" placeholder="Enter Your Mail ID" required class="txt"/></td>
					</tr>
					<tr align="center">
						<td><input type="text" name="subtxt" placeholder="Enter Subject" required class="txt"/></td>
					</tr>
					<tr align="center">
						<td><textarea name="message" rows="4" placeholder="Enter Message" required class="txt"></textarea></td>
					</tr>
					<tr align="center">
						<td><input type="Submit" name="send" value="Send" class="btn"/></td>
					</tr>
					<tr align="center">
						<td><span><?php echo $result;?></span></td>
					</tr>
				</table>
			</form>
			<h3 style="margin-top:30px;">Other Contact Details</h3>
			<table class="content">
				<tr>
					<td>Mobile No.</td>
					<td><a href="tel:8095237237" class="contact">8095237237</a></td>
				</tr>
				<tr>
					<td>Mail ID</td>
					<td><a href="mailto:grevathig02@gmail.com" class="contact">grevathig02@gmail.com</a></td>
				</tr>
			</table>
			</center></div>
		</main>
		<footer>
			<center style="background:#e6e6e6; margin:0;padding:5px;font-size:12px;"><small>COPYRIGHT &copy;<?php echo date("Y",strtotime('today'));?> SAI RAM SANSKRUTHI VIDHYALAYA</small></center>
		</footer>	
	</body>
</html>
