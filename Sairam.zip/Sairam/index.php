<?php
	session_start();
?>
<!doctype html>
<html>
	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<meta http-equiv="X-UA-Compatible" content="ie=edge" />
		<link rel="icon" href="data/img/icon.jpg" />
		<link href="data/css/index.css" rel="stylesheet" />
		<title>Sai Ram Sanskruthi Vidhyalaya</title>
	</head>
	<body>
		<header>
			<img src="data/img/logo.png" id="logo" width="180px" />
			<?php
				if($_SESSION['loggedin']===true){
					echo '<a href="data/php/login/logout.php"><b><i id="login">Log Out</i></b></a>';
				}
				else{
					echo '<a href="data/php/login/login.php"><b><i id="login">Login</i></b></a>';
				}
			?>
		</header>
		<main>
				
		</main>
		<footer>
			<center style="background:#e6e6e6; margin:0;padding:5px;font-size:12px;"><small>COPYRIGHT &copy;<?php echo date("Y",strtotime('today'));?> SAI RAM SANSKRUTHI VIDHYALAYA</small></center>
		</footer>
	</body>
</html>
